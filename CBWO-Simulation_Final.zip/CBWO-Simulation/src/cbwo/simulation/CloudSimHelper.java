package cbwo.simulation;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.CloudletSchedulerTimeShared;
import org.cloudbus.cloudsim.Datacenter;
import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.UtilizationModel;
import org.cloudbus.cloudsim.UtilizationModelFull;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.VmAllocationPolicySimple;
import org.cloudbus.cloudsim.VmSchedulerTimeShared;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;

public class CloudSimHelper {

    public static Datacenter createDatacenter(String name, int numHosts) {
        List<Host> hostList = new ArrayList<>();
        int hostId = 0;

        for (int i = 0; i < numHosts; i++) {
            List<Pe> peList = new ArrayList<>();
            // Host MIPS and RAM are increased to support 50 VMs on 6 hosts,
            // as the paper does not specify host characteristics.
            int mips = 40000; 
            peList.add(new Pe(0, new PeProvisionerSimple(mips)));

            int ram = 32768; // 32 GB
            long storage = 1000000;
            int bw = 10000;

            hostList.add(
                new Host(
                    hostId++,
                    new RamProvisionerSimple(ram),
                    new BwProvisionerSimple(bw),
                    storage,
                    peList,
                    new VmSchedulerTimeShared(peList)
                )
            );
        }

        String arch = "x86";
        String os = "Linux";
        String vmm = "Xen";
        double time_zone = 10.0;
        double cost = 3.0;
        double costPerMem = 0.05;
        double costPerStorage = 0.001;
        double costPerBw = 0.0;
        LinkedList<Storage> storageList = new LinkedList<>();

        DatacenterCharacteristics characteristics = new DatacenterCharacteristics(
                arch, os, vmm, hostList, time_zone, cost, costPerMem, costPerStorage, costPerBw);

        Datacenter datacenter = null;
        try {
            datacenter = new Datacenter(name, characteristics, new VmAllocationPolicySimple(hostList), storageList, 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return datacenter;
    }

    public static List<Vm> createVmList(int brokerId, int numVms) {
        List<Vm> vmlist = new ArrayList<>();
        Random random = new Random();
        
        long size = 10000;
        // This MIPS value is inferred from experimentation to match the paper's results,
        // as it is not specified in the paper for this experiment.
        int mips = 4000; 
        int pesNumber = 1;
        String vmm = "Xen";

        for (int i = 0; i < numVms; i++) {
            // VM RAM and Bandwidth are now randomized as per the paper's specification.
            int ram = 256 + random.nextInt(1793); // Range: 256-2048 MB
            long bw = 500 + random.nextInt(501);   // Range: 500-1000 Mbit/s

            Vm vm = new Vm(
                i,
                brokerId,
                mips,
                pesNumber,
                ram,
                bw,
                size,
                vmm,
                new CloudletSchedulerTimeShared()
            );
            vmlist.add(vm);
        }
        return vmlist;
    }

    public static List<Cloudlet> createCloudletList(int brokerId, int numCloudlets) {
        List<Cloudlet> cloudletList = new ArrayList<>();
        
        long fileSize = 300;
        long outputSize = 300;
        int pesNumber = 1;
        UtilizationModel utilizationModel = new UtilizationModelFull();
        Random random = new Random();

        for (int i = 0; i < numCloudlets; i++) {
            // Task length is randomized as per the paper's specification.
            long length = 1000 + random.nextInt(19001); 
            
            Cloudlet cloudlet = new Cloudlet(
                i,
                length,
                pesNumber,
                fileSize,
                outputSize,
                utilizationModel,
                utilizationModel,
                utilizationModel
            );
            cloudlet.setUserId(brokerId);
            cloudletList.add(cloudlet);
        }
        return cloudletList;
    }
}