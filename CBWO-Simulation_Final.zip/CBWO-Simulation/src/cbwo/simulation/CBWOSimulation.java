package cbwo.simulation;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.Datacenter;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.core.CloudSim;

public class CBWOSimulation {

    public static void main(String[] args) {
        System.out.println("Starting CBWO Simulation...");

        try {
            // 1. Initialize CloudSim
            int num_user = 1;
            Calendar calendar = Calendar.getInstance();
            boolean trace_flag = false;
            CloudSim.init(num_user, calendar, trace_flag);

            // 2. Define simulation parameters from the paper (Figure 8 experiment)
            int numVms = 50;
            int numCloudlets = 200;
            int numDatacenters = 10; // As specified in the paper
            int numHostsPerDC = 6;   // As specified in the paper (2-6 range)

            // 3. Create Datacenter(s)
            // The paper specifies 10 datacenters for this experiment.
            for (int i = 0; i < numDatacenters; i++) {
                CloudSimHelper.createDatacenter("Datacenter_" + i, numHostsPerDC);
            }

            // 4. Create the custom CBWOBroker
            CBWOBroker broker = new CBWOBroker("CBWOBroker");
            int brokerId = broker.getId();
            
            // 5. Create the lists of VMs and Cloudlets
            List<Vm> vmlist = CloudSimHelper.createVmList(brokerId, numVms);
            List<Cloudlet> cloudletlist = CloudSimHelper.createCloudletList(brokerId, numCloudlets);
            
            broker.submitVmList(vmlist);
            broker.submitCloudletList(cloudletlist);
            
            // 6. Run the CBWO algorithm via the broker's scheduleTasks method
            broker.scheduleTasks();

            // 7. Start the simulation
            CloudSim.startSimulation();

            // 8. Stop simulation and retrieve results
            CloudSim.stopSimulation();
            List<Cloudlet> newList = broker.getCloudletReceivedList();

            // 9. Print the results
            printCloudletList(newList);
            
            System.out.println("CBWO Simulation finished!");

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("The simulation has been terminated due to an error");
        }
    }
    
    private static void printCloudletList(List<Cloudlet> list) {
        int size = list.size();
        Cloudlet cloudlet;

        String indent = "    ";
        System.out.println();
        System.out.println("========== OUTPUT ==========");
        System.out.println("Cloudlet ID" + indent + "STATUS" + indent +
                "Data center ID" + indent + "VM ID" + indent + "Time" + indent + "Start Time" + indent + "Finish Time");

        for (int i = 0; i < size; i++) {
            cloudlet = list.get(i);
            System.out.print(indent + cloudlet.getCloudletId() + indent + indent);

            if (cloudlet.getCloudletStatus() == Cloudlet.SUCCESS) {
                System.out.print("SUCCESS");

                System.out.println(indent + indent + cloudlet.getResourceId() + indent + indent + indent + cloudlet.getVmId() +
                        indent + indent + String.format("%.2f", cloudlet.getActualCPUTime()) + indent + indent + String.format("%.2f", cloudlet.getExecStartTime()) +
                        indent + indent + String.format("%.2f", cloudlet.getFinishTime()));
            }
        }
    }
}