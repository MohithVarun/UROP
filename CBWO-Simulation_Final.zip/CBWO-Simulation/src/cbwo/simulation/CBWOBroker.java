package cbwo.simulation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.cloudbus.cloudsim.DatacenterBroker;

public class CBWOBroker extends DatacenterBroker {

    public CBWOBroker(String name) throws Exception {
        super(name);
    }

    public void scheduleTasks() {
        System.out.println("Starting CBWO Algorithm to find optimal task allocation...");

        int[] bestMap = findOptimalAllocation();

        System.out.println("CBWO Algorithm finished. Binding tasks to VMs according to the best solution found.");

        for (int i = 0; i < bestMap.length; i++) {
            bindCloudletToVm(getCloudletList().get(i).getCloudletId(), getVmList().get(bestMap[i]).getId());
        }
    }

    /** Inner class representing a widow (candidate solution) **/
    private static class Widow implements Comparable<Widow> {
        int[] taskToVmMap;
        double fitness;

        public Widow(int numTasks) {
            this.taskToVmMap = new int[numTasks];
            this.fitness = Double.MAX_VALUE;
        }

        public Widow(Widow other) {
            this.taskToVmMap = Arrays.copyOf(other.taskToVmMap, other.taskToVmMap.length);
            this.fitness = other.fitness;
        }

        @Override
        public int compareTo(Widow other) {
            return Double.compare(this.fitness, other.fitness);
        }
    }

    /** Chaotic maps **/
    private static double logisticMapX = Math.random();
    private static final double LOGISTIC_MAP_R = 4.0;

    private static double tentMapX = Math.random();
    private static final double TENT_MAP_M = 1.5;

    public static double getLogisticMapRandom() {
        logisticMapX = LOGISTIC_MAP_R * logisticMapX * (1 - logisticMapX);
        return logisticMapX;
    }

    public static double getTentMapRandom() {
        if (tentMapX < 0.5) {
            tentMapX = TENT_MAP_M * tentMapX;
        } else {
            tentMapX = TENT_MAP_M * (1 - tentMapX);
        }
        return tentMapX;
    }

    /** Generate offspring using crossover **/
    private List<Widow> procreate(Widow parent1, Widow parent2) {
        List<Widow> offspring = new ArrayList<>();
        int numTasks = parent1.taskToVmMap.length;

        Widow child1 = new Widow(parent1);
        Widow child2 = new Widow(parent2);

        int crossoverPoint = (int) (getLogisticMapRandom() * numTasks);

        for (int j = crossoverPoint; j < numTasks; j++) {
            int temp = child1.taskToVmMap[j];
            child1.taskToVmMap[j] = child2.taskToVmMap[j];
            child2.taskToVmMap[j] = temp;
        }

        offspring.add(child1);
        offspring.add(child2);

        return offspring;
    }

    /** Keep the best individuals after reproduction **/
    private List<Widow> performCannibalism(List<Widow> parents, List<Widow> offspring, int populationSize) {
        List<Widow> combined = new ArrayList<>(parents);
        combined.addAll(offspring);

        for (Widow w : offspring) {
            if (w.fitness == Double.MAX_VALUE) {
                w.fitness = calculateFitness(w);
            }
        }

        Collections.sort(combined);
        return new ArrayList<>(combined.subList(0, Math.min(combined.size(), populationSize)));
    }

    /** Mutation operation **/
    private void mutate(Widow widow) {
        int numTasks = widow.taskToVmMap.length;
        int task1 = (int) (getLogisticMapRandom() * numTasks);
        int task2 = (int) (getLogisticMapRandom() * numTasks);

        int tempVmId = widow.taskToVmMap[task1];
        widow.taskToVmMap[task1] = widow.taskToVmMap[task2];
        widow.taskToVmMap[task2] = tempVmId;
    }

    /** Main CBWO algorithm — returns best task→VM map **/
    public int[] findOptimalAllocation() {
        int populationSize = 10;
        int maxIterations = 10;
        double procreateRate = 0.6;
        double mutationRate = 0.5;

        int numTasks = getCloudletList().size();
        int numVms = getVmList().size();

        List<Widow> population = new ArrayList<>();
        for (int i = 0; i < populationSize; i++) {
            Widow widow = new Widow(numTasks);
            for (int j = 0; j < numTasks; j++) {
                widow.taskToVmMap[j] = (int) (getTentMapRandom() * numVms);
            }
            widow.fitness = calculateFitness(widow);
            population.add(widow);
        }
        Collections.sort(population);

        for (int iter = 0; iter < maxIterations; iter++) {
            int numToProcreate = (int) (populationSize * procreateRate);
            List<Widow> parents = new ArrayList<>(population.subList(0, numToProcreate));
            List<Widow> offspring = new ArrayList<>();

            for (int i = 0; i < parents.size() / 2; i++) {
                Widow p1 = parents.get((int) (getLogisticMapRandom() * parents.size()));
                Widow p2 = parents.get((int) (getLogisticMapRandom() * parents.size()));
                offspring.addAll(procreate(p1, p2));
            }

            population = performCannibalism(parents, offspring, populationSize);

            int numToMutate = (int) (populationSize * mutationRate);
            for (int i = 0; i < numToMutate; i++) {
                if (population.isEmpty()) continue;
                int widowIndex = (int) (getLogisticMapRandom() * population.size());
                Widow toMutate = new Widow(population.get(widowIndex));
                mutate(toMutate);
                toMutate.fitness = calculateFitness(toMutate);
                population.add(toMutate);
            }

            Collections.sort(population);
            if (population.size() > populationSize) {
                population = new ArrayList<>(population.subList(0, populationSize));
            }

            if (!population.isEmpty()) {
                System.out.println("Iteration " + (iter + 1) + ": Best Fitness = " + population.get(0).fitness);
            }
        }

        return population.get(0).taskToVmMap;
    }

    /** Fitness = makespan **/
    private double calculateFitness(Widow solution) {
        double[] vmFinishTimes = new double[getVmList().size()];

        for (int i = 0; i < solution.taskToVmMap.length; i++) {
            int vmId = solution.taskToVmMap[i];
            double taskLength = getCloudletList().get(i).getCloudletLength();
            double vmSpeed = getVmList().get(vmId).getMips();
            double executionTime = taskLength / vmSpeed;
            vmFinishTimes[vmId] += executionTime;
        }

        double makespan = 0.0;
        for (double finishTime : vmFinishTimes) {
            if (finishTime > makespan) {
                makespan = finishTime;
            }
        }

        return makespan;
    }
}