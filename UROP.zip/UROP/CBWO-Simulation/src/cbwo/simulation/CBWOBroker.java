package cbwo.simulation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.cloudbus.cloudsim.DatacenterBroker;

public class CBWOBroker extends DatacenterBroker {

    public CBWOBroker(String name) throws Exception {
        super(name);
    }

    /**
     * This method is the entry point for running the optimization.
     * It calls the CBWO algorithm and then uses the result to
     * bind tasks to VMs before the simulation starts.
     */
    public void scheduleTasks() {
        System.out.println("Starting CBWO Algorithm to find optimal task allocation...");

        // Run the CBWO algorithm to get the best mapping
        int[] bestMap = findOptimalAllocation(); // Corrected: return type is int[]

        System.out.println("CBWO Algorithm finished. Binding tasks to VMs according to the best solution found.");

        // Bind cloudlets to VMs based on the best mapping found
        for (int i = 0; i < bestMap.length; i++) {
            bindCloudletToVm(getCloudletList().get(i).getCloudletId(), getVmList().get(bestMap[i]).getId());
        }
    }

    /**
     * Inner class to represent a single solution (a "widow").
     * Each solution is a map of tasks to VMs, represented by an array.
     */
    private static class Widow implements Comparable<Widow> {
        int[] taskToVmMap; // Corrected: changed to int[]
        double fitness;

        public Widow(int numTasks) {
            this.taskToVmMap = new int[numTasks]; // Correct initialization
            this.fitness = Double.MAX_VALUE;
        }

        // Copy constructor
        public Widow(Widow other) {
            this.taskToVmMap = Arrays.copyOf(other.taskToVmMap, other.taskToVmMap.length);
            this.fitness = other.fitness;
        }

        @Override
        public int compareTo(Widow other) {
            return Double.compare(this.fitness, other.fitness);
        }
    }

    // Static members for the chaotic maps
    private static double logisticMapX = Math.random();
    private static final double LOGISTIC_MAP_R = 4.0;

    private static double tentMapX = Math.random();
    private static final double TENT_MAP_M = 1.5;

    /**
     * Implements the Logistic Map from Eq. (12) of the paper.
     * @return A chaotic random number between 0 and 1.
     */
    public static double getLogisticMapRandom() {
        logisticMapX = LOGISTIC_MAP_R * logisticMapX * (1 - logisticMapX);
        return logisticMapX;
    }

    /**
     * Implements the Tent Map from Eq. (11) of the paper.
     * @return A chaotic random number between 0 and 1.
     */
    public static double getTentMapRandom() {
        if (tentMapX < 0.5) {
            tentMapX = TENT_MAP_M * tentMapX;
        } else {
            tentMapX = TENT_MAP_M * (1 - tentMapX);
        }
        return tentMapX;
    }

    /**
     * BWO Procreation operator. Creates new solutions from two parents.
     */
    private List<Widow> procreate(Widow parent1, Widow parent2) {
        List<Widow> offspring = new ArrayList<Widow>();
        int numTasks = parent1.taskToVmMap.length;

        Widow child1 = new Widow(parent1);
        Widow child2 = new Widow(parent2);

        int crossoverPoint = (int) (getLogisticMapRandom() * numTasks);

        // One-point crossover
        for (int j = crossoverPoint; j < numTasks; j++) {
            int temp = child1.taskToVmMap[j];
            child1.taskToVmMap[j] = child2.taskToVmMap[j];
            child2.taskToVmMap[j] = temp;
        }

        offspring.add(child1);
        offspring.add(child2);
        return offspring;
    }

    /**
     * BWO Cannibalism operator. Selects the fittest individuals from a combined list.
     */
    private List<Widow> performCannibalism(List<Widow> parents, List<Widow> offspring, int populationSize) {
        List<Widow> combined = new ArrayList<Widow>(parents);
        combined.addAll(offspring);

        for (Widow w : offspring) {
            if (w.fitness == Double.MAX_VALUE) {
                w.fitness = calculateFitness(w);
            }
        }

        Collections.sort(combined);

        // Keep only the best up to population size
        return new ArrayList<Widow>(combined.subList(0, Math.min(combined.size(), populationSize)));
    }

    /**
     * BWO Mutation operator. Randomly swaps two task assignments in a solution.
     */
    private void mutate(Widow widow) {
        int numTasks = widow.taskToVmMap.length;
        int task1 = (int) (getLogisticMapRandom() * numTasks);
        int task2 = (int) (getLogisticMapRandom() * numTasks);

        int tempVmId = widow.taskToVmMap[task1];
        widow.taskToVmMap[task1] = widow.taskToVmMap[task2];
        widow.taskToVmMap[task2] = tempVmId;
    }

    /**
     * The main CBWO algorithm loop.
     * @return The best task-to-VM mapping found.
     */
    public int[] findOptimalAllocation() { // Corrected return type to int[]
        // CBWO parameters
        int populationSize = 20;
        int maxIterations = 50;
        double procreateRate = 0.6;
        double mutationRate = 0.5;

        int numTasks = getCloudletList().size();
        int numVms = getVmList().size();

        // 1. Initialization using Tent Map
        List<Widow> population = new ArrayList<Widow>();
        for (int i = 0; i < populationSize; i++) {
            Widow widow = new Widow(numTasks);
            for (int j = 0; j < numTasks; j++) {
                widow.taskToVmMap[j] = (int) (getTentMapRandom() * numVms);
            }
            widow.fitness = calculateFitness(widow);
            population.add(widow);
        }
        Collections.sort(population);

        // 2. Main Iteration Loop
        for (int iter = 0; iter < maxIterations; iter++) {
            int numToProcreate = (int) (populationSize * procreateRate);
            List<Widow> parents = new ArrayList<Widow>(population.subList(0, numToProcreate));
            List<Widow> offspring = new ArrayList<Widow>();

            for (int i = 0; i < parents.size() / 2; i++) {
                Widow p1 = parents.get((int) (getLogisticMapRandom() * parents.size()));
                Widow p2 = parents.get((int) (getLogisticMapRandom() * parents.size()));
                offspring.addAll(procreate(p1, p2));
            }

            // Cannibalism
            population = performCannibalism(parents, offspring, populationSize);

            // Mutation
            int numToMutate = (int) (populationSize * mutationRate);
            for (int i = 0; i < numToMutate; i++) {
                if (population.isEmpty()) continue;
                int widowIndex = (int) (getLogisticMapRandom() * population.size());
                Widow toMutate = new Widow(population.get(widowIndex));
                mutate(toMutate);
                toMutate.fitness = calculateFitness(toMutate);
                population.add(toMutate);
            }

            // Sort and trim
            Collections.sort(population);
            if (population.size() > populationSize) {
                population = new ArrayList<Widow>(population.subList(0, populationSize));
            }

            if (!population.isEmpty()) {
                System.out.println("Iteration " + (iter + 1) + ": Best Fitness = " + population.get(0).fitness);
            }
        }

        // Return the best mapping
        return population.get(0).taskToVmMap;
    }

    /**
     * Calculates the fitness of a given solution.
     * @param solution The solution to evaluate.
     * @return The fitness score (lower is better).
     */
    private double calculateFitness(Widow solution) {
        double[] vmFinishTimes = new double[getVmList().size()]; // Corrected type

        for (int i = 0; i < solution.taskToVmMap.length; i++) {
            int vmId = solution.taskToVmMap[i];
            double taskLength = getCloudletList().get(i).getCloudletLength();
            double vmSpeed = getVmList().get(vmId).getMips();
            double executionTime = taskLength / vmSpeed;
            vmFinishTimes[vmId] += executionTime;
        }

        double makespan = 0.0;
        for (int i = 0; i < vmFinishTimes.length; i++) {
            if (vmFinishTimes[i] > makespan) {
                makespan = vmFinishTimes[i];
            }
        }

        return makespan;
    }
}