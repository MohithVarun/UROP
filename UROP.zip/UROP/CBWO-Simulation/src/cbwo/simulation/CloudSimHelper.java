package cbwo.simulation;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Random; // Make sure this import is added
import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.CloudletSchedulerTimeShared;
import org.cloudbus.cloudsim.Datacenter;
import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.UtilizationModel;
import org.cloudbus.cloudsim.UtilizationModelFull;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.VmAllocationPolicySimple;
import org.cloudbus.cloudsim.VmSchedulerTimeShared;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;

public class CloudSimHelper {

    /**
     * Creates a Datacenter object.
     * @param name The name of the datacenter.
     * @param numHosts The number of physical host machines in the datacenter.
     * @return The created Datacenter object.
     */
    public static Datacenter createDatacenter(String name, int numHosts) {
        List<Host> hostList = new ArrayList<>();
        int hostId = 0;

        for (int i = 0; i < numHosts; i++) {
            List<Pe> peList = new ArrayList<>();
            int mips = 16000;
            peList.add(new Pe(0, new PeProvisionerSimple(mips)));

            int ram = 2048;
            long storage = 1000000;
            int bw = 10000;

            hostList.add(
                new Host(
                    hostId++,
                    new RamProvisionerSimple(ram),
                    new BwProvisionerSimple(bw),
                    storage,
                    peList,
                    new VmSchedulerTimeShared(peList)
                )
            );
        }

        String arch = "x86";
        String os = "Linux";
        String vmm = "Xen";
        double time_zone = 10.0;
        double cost = 3.0;
        double costPerMem = 0.05;
        double costPerStorage = 0.001;
        double costPerBw = 0.0;
        LinkedList<Storage> storageList = new LinkedList<>();

        DatacenterCharacteristics characteristics = new DatacenterCharacteristics(
                arch, os, vmm, hostList, time_zone, cost, costPerMem, costPerStorage, costPerBw);

        Datacenter datacenter = null;
        try {
            datacenter = new Datacenter(name, characteristics, new VmAllocationPolicySimple(hostList), storageList, 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return datacenter;
    }

    /**
     * Creates a list of Virtual Machines.
     * @param brokerId The ID of the broker that owns these VMs.
     * @param numVms The number of VMs to create.
     * @return A list of Vm objects.
     */
    public static List<Vm> createVmList(int brokerId, int numVms) {
        List<Vm> vmlist = new ArrayList<>();
        
        long size = 10000;
        int ram = 512;
        int mips = 4000;
        long bw = 1000;
        int pesNumber = 1;
        String vmm = "Xen";

        for (int i = 0; i < numVms; i++) {
            Vm vm = new Vm(
                i,
                brokerId,
                mips,
                pesNumber,
                ram,
                bw,
                size,
                vmm,
                new CloudletSchedulerTimeShared()
            );
            vmlist.add(vm);
        }
        return vmlist;
    }

    /**
     * Creates a list of Cloudlets (tasks) with varying lengths as per the paper.
     * @param brokerId The ID of the broker that owns these tasks.
     * @param numCloudlets The number of tasks to create.
     * @return A list of Cloudlet objects.
     */
    public static List<Cloudlet> createCloudletList(int brokerId, int numCloudlets) {
        List<Cloudlet> cloudletList = new ArrayList<>();
        
        long fileSize = 300;
        long outputSize = 300;
        int pesNumber = 1;
        UtilizationModel utilizationModel = new UtilizationModelFull();
        Random random = new Random();

        for (int i = 0; i < numCloudlets; i++) {
            // This now creates tasks with random lengths between 1000 and 20,000 MI,
            // exactly as specified in the paper for the Figure 8 experiment.
            long length = 1000 + random.nextInt(19001); 
            
            Cloudlet cloudlet = new Cloudlet(
                i,
                length,
                pesNumber,
                fileSize,
                outputSize,
                utilizationModel,
                utilizationModel,
                utilizationModel
            );
            cloudlet.setUserId(brokerId);
            cloudletList.add(cloudlet);
        }
        return cloudletList;
    }
}